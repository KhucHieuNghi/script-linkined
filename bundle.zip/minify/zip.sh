#!/bin/bash
set -e

zip -r minify bundle
